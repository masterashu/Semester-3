#include <iostream>
#include <string>
#include <windows.h>
#include <winsock.h>
#include "mysql.h"

using namespace std;

int main()
{
    MYSQL* conn;
    MYSQL_ROW row;
    MYSQL_RES *res;
    int qstate;

       conn = mysql_init(0);
    if(conn)
        cout<<"connection object ok, conn="<<conn<<endl;
    else
        cout<<"conn object problem: "<<mysql_error(conn);

    conn = mysql_real_connect(conn,"localhost","root","","ebookshop",0,NULL,0);

    if(conn)
    {
        cout<<"connected to database ebookshop"<<endl;

        string id,title,auth_name,price,qty;
        cout<<"enter id: "<<endl; cin>>id;
        cout<<"enter book title: "<<endl; cin>>title;
        cout<<"enter author name: "<<endl; cin>>auth_name;
        cout<<"enter price: "<<endl; cin>>price;
        cout<<"enter qty: "<<endl; cin>>qty;



        string query="insert into books(id,title,author,price,qty) values('"+id+"','"+title+"','"+auth_name+"','"+price+"','"+qty+"')";

        const char* q = query.c_str();

        cout<<"query is: "<<q<<endl;
        qstate = mysql_query(conn,q);

        if(!qstate)
            cout<<"record inserted successfully..."<<endl;
        else
            cout<<"query problem: "<<mysql_error(conn)<<endl;

        qstate = mysql_query(conn,"select * from books");

        if(!qstate)
        {
            res = mysql_store_result(conn);
            while(row=mysql_fetch_row(res))
            {
                cout<<"id: "<<row[0]<< " "
                    <<"name: "<<row[1]<< " "
                    <<"phone: "<<row[2]<<endl;
            }
        }
        else
        {
            cout<<"query error: "<<mysql_error(conn)<<endl;
        }
    }
    else
    {
        cout<<"connection problem: "<<mysql_error(conn)<<endl;
    }

    mysql_close(conn);

    return 0;
}
